package com.example.meznahsulaiman.e_menu;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Field;
import java.util.ArrayList;


public class MenuActivity extends ActionBarActivity {

private static  String resName;
    private static  int imgid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        ArrayList<ListItem> items = new ArrayList<ListItem>();
        items.add(new ListItem(R.drawable.s1));
        items.add(new ListItem(R.drawable.s2));
        items.add(new ListItem(R.drawable.s3));
        items.add(new ListItem(R.drawable.s4));
        MyCustomAdapter MyAdapter= new MyCustomAdapter(items);

        ListView ls=(ListView)findViewById(R.id.listView);
        ls.setAdapter(MyAdapter);
        ls.setOnItemClickListener(MyAdapter);

    }


   class MyCustomAdapter extends BaseAdapter implements AdapterView.OnItemClickListener
    {
        ArrayList<ListItem> items = new ArrayList<ListItem>();
        MyCustomAdapter(ArrayList<ListItem> items)
        {
            this.items=items;
        }



        @Override
        public int getCount()
        {
            return items.size();

        }

        @Override
        public Object getItem(int position)
        {
            return items.get(position);

        }

        @Override
        public long getItemId(int position)
        {
            return position;

        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup)
        {
            LayoutInflater layoutInflater= getLayoutInflater();
            View view1 = layoutInflater.inflate(R.layout.row_view, null);

            ImageView image = (ImageView) view1.findViewById(R.id.imageView);
            ListItem temp = items.get(i);
            image.setImageResource(temp.img);


            return view1;

        }

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            ViewGroup vg= (ViewGroup) view;
            ImageView image = (ImageView) view.findViewById(R.id.imageView);



           //  imgid=(Integer)image.getId();
         // count = items.indexOf(R.drawable.s1);


           // resName = getResourceNameFromClassByID(R.drawable.class, R.drawable.s1);

               Toast.makeText(MenuActivity.this, "Hello1", Toast.LENGTH_SHORT).show();



        }
    }

   public String getResourceNameFromClassByID(Class<?> aClass, int resourceID)
            throws IllegalArgumentException{
                /* Get all Fields from the class passed. */
        Field[] drawableFields = aClass.getFields();

                /* Loop through all Fields. */
        for(Field f : drawableFields){
            try {
                                /* All fields within the subclasses of R
                                 * are Integers, so we need no type-check here. */

                                /* Compare to the resourceID we are searching. */
                if (resourceID == f.getInt(null))
                    return f.getName(); // Return the name.
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
                /* Throw Exception if nothing was found*/
        throw new IllegalArgumentException();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
